package servlet;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import java.io.IOException;

@WebServlet(name = "LifeCycle", urlPatterns = "/Servlet3")
public class Servlet3LifeCycle extends GenericServlet {
    @Override
    public void init(ServletConfig config) throws ServletException {
        System.out.println("Init method is called.");
    }

    @Override
    public void service(ServletRequest servletRequest, ServletResponse servletResponse)
            throws ServletException, IOException {
        System.out.println("Hello, LiuJiaQi.");
    }

    @Override
    public void destroy() {
        System.out.println("Destroy method is called.");
    }
}