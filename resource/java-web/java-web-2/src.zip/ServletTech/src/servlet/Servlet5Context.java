package servlet;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

@WebServlet(name = "Context", urlPatterns = "/Servlet5")
public class Servlet5Context extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();
        ServletContext context = getServletContext();
        Enumeration<String> parameterNames = context.getInitParameterNames();

        out.println("All the parameterNames and parameterValues are following:<br/>");
        while (parameterNames.hasMoreElements()) {
            String parameterName = parameterNames.nextElement();
            String parameterValue = context.getInitParameter(parameterName);
            out.println(parameterName + "：" + parameterValue);
            out.println("<br/>");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.doGet(request, response);
    }
}