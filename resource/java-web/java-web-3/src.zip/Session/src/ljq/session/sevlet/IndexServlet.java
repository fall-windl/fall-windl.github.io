package ljq.session.sevlet;

import ljq.session.entity.User;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet(name = "IndexServlet", value = "/IndexServlet")
public class IndexServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html; charset=utf-8");
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        if (user == null) {
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        } else {
            String value = null;
            Cookie[] cookies = request.getCookies();
            if (cookies.length != 0 && cookies != null) {
                for (Cookie cookie : cookies) {
                    String name = cookie.getName();
                    if (name.equals("lastTime")) {
                        value = cookie.getValue();
                        value = URLDecoder.decode(value, "utf-8");
                    }
                }
            }
            if (value == null) {
                request.setAttribute("message", "初次登录，欢迎您，" + user.getUsername() + "!");
                Date date = new Date();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日" + "HH:mm:ss");
                String str_date = sdf.format(date);
                str_date = URLDecoder.decode(str_date, "utf-8");
                Cookie dateCookie = new Cookie("lastTime", str_date);
                dateCookie.setMaxAge(-1);
                response.addCookie(dateCookie);
            } else {
                request.setAttribute("message", "欢迎回来，" + user.getUsername() + "，上次访问时间：" + value + "。");
            }
            Cookie cookie = new Cookie("JSESSIONID", session.getId());
            cookie.setMaxAge(-1);
            cookie.setPath("/Session_war_exploded");
            response.addCookie(cookie);
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.doGet(request, response);
    }
}
