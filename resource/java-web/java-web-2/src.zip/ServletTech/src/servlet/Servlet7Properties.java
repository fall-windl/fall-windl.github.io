package servlet;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Properties;

@WebServlet(name = "Properties", urlPatterns = "/Servlet7")
public class Servlet7Properties extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();
        ServletContext context = getServletContext();
        InputStream in = context.getResourceAsStream("/WEB-INF/classes/liujiaqi.properties");

        Properties prop = new Properties();
        prop.load(in);
        Enumeration<Object> properties = prop.keys();
        while (properties.hasMoreElements()) {
            String key = (String) properties.nextElement();
            String value = prop.getProperty(key);
            out.println(key + " = " + value + "<br/>");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.doGet(request, response);
    }
}